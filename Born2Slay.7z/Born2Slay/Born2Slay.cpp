#include "raylib.h"
#include "raymath.h"

class Character
{
    public:

    private:
    
};

int main()
{
    const int windorWidth{384};
    const int windowHeight{384};
    InitWindow(windorWidth, windowHeight, "Born2Slay!");

    Texture2D map = LoadTexture("nature_tileset/WorldMap.png");
    Vector2 mapPos{0.0};
    float speed{4.0};

    Texture2D war_idle = LoadTexture("characters/warrior_idle_spritesheet.png");
    Texture2D war_run = LoadTexture("characters/war_run_spritesheet.png");

    Texture2D war = LoadTexture("characters/warrior_idle_spritesheet.png");
    Vector2 warPos{
        (float)windorWidth/2.0f - 4.0f * (0.5f * (float)war.width/6.0f),
        (float)windowHeight/2.0f - 4.0f * (0.5f * (float)war.height)
    };
    float rightLeft{1.f};
    float runningTime{};
    int frame{};
    const int maxFrames{6};
    const float updateTime{1.f/12.f};

    SetTargetFPS(60);
    while (!WindowShouldClose())
    {
        BeginDrawing();
        ClearBackground(WHITE);

        Vector2 direction{};
        if (IsKeyDown(KEY_A)) direction.x -= 1.0;
        if (IsKeyDown(KEY_D)) direction.x += 1.0;
        if (IsKeyDown(KEY_W)) direction.y -= 1.0;
        if (IsKeyDown(KEY_S)) direction.y += 1.0;
        if (Vector2Length(direction) != 0.0)
        {

            
            mapPos = Vector2Subtract(mapPos, Vector2Scale(Vector2Normalize(direction), speed));
            direction.x < 0.f ? rightLeft = -1.f : rightLeft = 1.f;
            war = war_run;
        }
        else
        {
            war = war_idle;
        }


        DrawTextureEx(map, mapPos, 0.0, 4.0, WHITE);

        runningTime += GetFrameTime();
        if (runningTime >= updateTime)
        {
            frame++;
            runningTime = 0.f;
            if (frame > maxFrames) frame = 0;
        }

        Rectangle source{frame * (float)war.width/6.f, 0.f,rightLeft * (float)war.width/6.f, (float)war.height};
        Rectangle dest{warPos.x, warPos.y, 4.0f * (float)war.width/6.0f, 4.0f * (float)war.height};
        DrawTexturePro(war, source, dest, Vector2{}, 0.f, WHITE);
        EndDrawing();
    }
    CloseWindow();
}